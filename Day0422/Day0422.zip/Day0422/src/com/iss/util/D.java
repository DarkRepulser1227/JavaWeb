package com.iss.util;

import org.junit.Test;

public class D {

    @Test
    public void show(){

        MailUtil.sendEmail("82469071@qq.com");

    }
}
